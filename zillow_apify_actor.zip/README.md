# Zillow Search Scraper (Apify Actor)

Scrapes **public** Zillow search results using Playwright on Apify. Saves a clean dataset with address, price, beds, baths, area, coordinates, zpid, status, and listing URL.

> ⚖️ **Important**: Use this tool only for lawful and permitted purposes. Review and comply with Zillow’s Terms of Use and robots.txt. Avoid collecting personal data. The actor targets *public* search results pages.

## Inputs (see INPUT_SCHEMA.json)
- `locations`: array of city/region strings or Zillow search URLs
- `listingTypes`: e.g., `["forSale","forRent","sold"]`
- `propertyTypes`: `["houses","condos","apartments","townhomes",...]`
- `minPrice`, `maxPrice`, `bedsMin`, `bathsMin`
- `maxPagesPerLocation`, `maxItems`
- `proxy`

## Run locally
```bash
npm i
APIFY_LOCAL_STORAGE_DIR=./storage node src/main.js
```
Provide `INPUT.json` in `storage/key_value_stores/default/`.

## Deploy on Apify
Create a new Actor → Start with JavaScript → upload this ZIP in **Source** → **Build** → **Run**.
