// src/main.js
import { Actor, log, Dataset, ProxyConfiguration } from 'apify';
import { PlaywrightCrawler } from 'crawlee';
import { routers } from './routers.js';

const ZILLOW_BASE = 'https://www.zillow.com';

Actor.main(async () => {
  const input = await Actor.getInput() || {};
  const {
    locations = [],
    listingTypes = ['forSale'],
    propertyTypes = ['houses', 'condos', 'apartments', 'townhomes'],
    minPrice,
    maxPrice,
    bedsMin = 0,
    bathsMin = 0,
    maxPagesPerLocation = 5,
    maxItems = 500,
    usePostalSearch = true,
    proxy = { useApifyProxy: true },
  } = input;

  if (!locations.length) throw new Error('No locations provided.');

  const proxyConfiguration = await ProxyConfiguration.create(proxy);
  const requestQueue = await Actor.openRequestQueue();

  for (const loc of locations) {
    if (/^https?:\/\//i.test(loc)) {
      await requestQueue.addRequest({
        url: loc,
        userData: { label: 'SEARCH', page: 1, location: loc, filters: {} },
      });
    } else {
      const url = buildSearchUrl({
        location: loc,
        listingTypes,
        propertyTypes,
        minPrice,
        maxPrice,
        bedsMin,
        bathsMin,
        usePostalSearch,
      });
      await requestQueue.addRequest({
        url,
        userData: {
          label: 'SEARCH',
          page: 1,
          location: loc,
          filters: { listingTypes, propertyTypes, minPrice, maxPrice, bedsMin, bathsMin },
        },
      });
    }
  }

  const state = await Actor.getValue('STATE') || { itemCount: 0 };
  const router = routers({ maxItems, maxPagesPerLocation, state });

  const crawler = new PlaywrightCrawler({
    requestQueue,
    proxyConfiguration,
    headless: true,
    maxRequestsPerCrawl: Math.max(50 * locations.length, 200),
    navigationTimeoutSecs: 45,
    maxConcurrency: 5,
    requestHandlerTimeoutSecs: 60,
    preNavigationHooks: [
      async ({ page }) => {
        await page.setViewportSize({ width: 1366, height: 768 });
      },
    ],
    requestHandler: async (ctx) => router.handle(ctx),
    failedRequestHandler: async ({ request }) => {
      log.warning(`Request failed ${request.url}`);
    },
  });

  await crawler.run();
  await Actor.setValue('STATE', state);
  log.info(`Done. Total items: ${state.itemCount}`);
});

function buildSearchUrl({
  location,
  listingTypes, // kept for future deep-filter use
  propertyTypes, // kept for future deep-filter use
  minPrice,
  maxPrice,
  bedsMin,
  bathsMin,
  usePostalSearch,
}) {
  const locSlug = encodeURIComponent(location.replace(/\s+/g, '-'));
  const base = `${ZILLOW_BASE}/homes/${locSlug}_rb/`;
  const params = new URLSearchParams();
  if (minPrice) params.set('price_min', String(minPrice));
  if (maxPrice) params.set('price_max', String(maxPrice));
  if (bedsMin) params.set('beds', String(bedsMin));
  if (bathsMin) params.set('baths', String(bathsMin));
  if (usePostalSearch) params.set('searchQueryState', JSON.stringify({ isListVisible: true }));
  return params.toString() ? `${base}?${params.toString()}` : base;
}
