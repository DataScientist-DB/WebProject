// src/routers.js
import { log, Dataset, sleep } from 'apify';

export const routers = ({ maxItems, maxPagesPerLocation, state }) => ({
  handle: async (ctx) => {
    const { request } = ctx;
    const label = request.userData?.label || 'SEARCH';
    switch (label) {
      case 'SEARCH':
      default:
        return handleSearchPage(ctx, { maxItems, maxPagesPerLocation, state });
    }
  },
});

function extractListResultsFromHtml(html) {
  const match = html.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]*?)<\/script>/);
  if (!match) return { listResults: [], resultsCount: 0, queryState: null };
  let nextData;
  try { nextData = JSON.parse(match[1]); } catch { return { listResults: [], resultsCount: 0, queryState: null }; }
  const root = nextData?.props?.pageProps?.searchPageState;
  const listResults = root?.cat1?.searchResults?.listResults || [];
  const resultsCount = root?.cat1?.searchList?.totalResultCount ?? listResults.length;
  const queryState = root?.queryState || root?.cat1?.searchList?.searchState || null;
  return { listResults, resultsCount, queryState };
}

function buildNextPageUrl(currentUrl, queryState, nextPage) {
  try {
    const url = new URL(currentUrl);
    const sqsRaw = url.searchParams.get('searchQueryState');
    let sqs = queryState || (sqsRaw ? JSON.parse(sqsRaw) : {});
    sqs.pagination = sqs.pagination || {};
    sqs.pagination.currentPage = nextPage;
    url.searchParams.set('searchQueryState', JSON.stringify(sqs));
    return url.toString();
  } catch {
    return null;
  }
}

async function handleSearchPage({ page, request }, { maxItems, maxPagesPerLocation, state }) {
  const { page: pageIndex = 1, location } = request.userData || {};
  log.info(`🧭 ${location || ''} | Page ${pageIndex}: ${request.url}`);

  await page.goto(request.url, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1500);

  const html = await page.content();
  const { listResults, resultsCount, queryState } = extractListResultsFromHtml(html);

  log.info(`Found ${listResults.length} items (reported total: ${resultsCount || 'n/a'})`);

  for (const item of listResults) {
    if (state.itemCount >= maxItems) {
      log.warning(`Hit maxItems=${maxItems}. Stopping collection.`);
      return;
    }
    const rec = mapZillowItem(item, request.url);
    await Dataset.pushData(rec);
    state.itemCount += 1;
  }

  if (pageIndex < maxPagesPerLocation && state.itemCount < maxItems) {
    const nextUrl = buildNextPageUrl(request.url, queryState, pageIndex + 1);
    if (nextUrl) {
      await page.goto(nextUrl, { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(1200);
      const nextReq = {
        url: nextUrl,
        userData: { ...request.userData, page: pageIndex + 1 },
      };
      return handleSearchPage({ page, request: nextReq }, { maxItems, maxPagesPerLocation, state });
    }
  }
}

function mapZillowItem(item, referer) {
  const {
    zpid, address, statusType, statusText, unformattedPrice, price, beds, baths, area,
    latLong, detailUrl, variableData, hdpData, homeType, timeOnZillow,
  } = item || {};
  const coords = latLong || {};
  const url = detailUrl?.startsWith('http') ? detailUrl : `https://www.zillow.com${detailUrl || ''}`;
  const yearBuilt = hdpData?.homeInfo?.yearBuilt ?? null;
  const lotArea = hdpData?.homeInfo?.lotAreaValue ?? null;
  const lotAreaUnit = hdpData?.homeInfo?.lotAreaUnit ?? null;

  return {
    zpid,
    url,
    referer,
    address,
    statusType,
    statusText,
    label: variableData?.text || null,
    homeType,
    priceRaw: unformattedPrice ?? null,
    priceText: price ?? null,
    beds: beds ?? null,
    baths: baths ?? null,
    areaSqft: area ?? null,
    latitude: coords?.latitude ?? null,
    longitude: coords?.longitude ?? null,
    yearBuilt,
    lotArea,
    lotAreaUnit,
    timeOnZillow: timeOnZillow ?? null,
    scrapedAt: new Date().toISOString(),
  };
}
